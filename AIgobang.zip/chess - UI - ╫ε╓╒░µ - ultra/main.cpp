#include <graphics.h>
#include <fstream>
#include <cstring>
#include <conio.h>
#include "AI.h"

const int GRID_SIZE = 50; // �̶�GRID_SIZEΪ50
const int HALF_GRID_SIZE = GRID_SIZE / 2;
const int PIECE_RADIUS = GRID_SIZE / 2 - 5;
const int BORDER_RADIUS = PIECE_RADIUS + 2; // ���ӱ߿�İ뾶

// ����һ����ť�ṹ
struct Button {
    int x, y, width, height;
    const char* label;
};

// ���ư�ť
void drawButton(const Button& button) {
    //���ư�ɫ�߿�
    setfillcolor(BLACK);
    fillrectangle(button.x-2, button.y-2, button.x + button.width + 2, button.y + button.height + 2);
    setfillcolor(GREEN); // ���ð�ť�����ɫ
    fillrectangle(button.x, button.y, button.x + button.width, button.y + button.height); // ���ƾ��ΰ�ť
    settextcolor(BLACK); // �����ı���ɫ
    outtextxy(button.x + 10, button.y + 10, button.label); // ���ư�ť�ϵ��ı�
}
//new������
void popupAboutWindow() {
    // ����һ���ϴ��������Ϊ��������
    setfillstyle(SOLID_FILL, WHITE);
    int left = 200, top = 200, right = 600, bottom = 600;
    bar(left, top, right, bottom);

    setcolor(BLACK);
    rectangle(left - 1, top - 1, right + 1, bottom + 1);
    rectangle(left + 1, top + 1, right - 1, bottom - 1);

    // ����ı�
    outtextxy(left + 10, top + 20, "About Gomoku Game");
    outtextxy(left + 10, top + 80, "Version: 1.2  Developed by: ");
    outtextxy(left + 10, top + 100, "�����죬�����壬����Ԫ�����٣�������");
    outtextxy(left + 10, top + 140, "Features: ");
    outtextxy(left + 10, top + 160, "- Single-player mode against a challenging AI.");
    outtextxy(left + 10, top + 180, "- Multiple difficulty levels ranging from 'Idiot' to 'Hard'.");
    outtextxy(left + 10, top + 200, "- Save and load game functionality.");
    outtextxy(left + 10, top + 220, "- Interactive UI with responsive buttons and scoreboard.");
    outtextxy(left + 10, top + 240, "- Exciting 'Player vs. AI' mode and 'Player vs. Player' mode");
    outtextxy(left + 10, top + 300, "Thank you for playing our Gomoku Game!");

    // �򻯰�رհ�ť��ʵ��ֻ��һ����
    int closeButtonSize = 20;
    int closeButtonLeft = right - closeButtonSize - 10;
    int closeButtonTop = top + 10;
    setfillstyle(SOLID_FILL, RED);
    bar(closeButtonLeft, closeButtonTop, closeButtonLeft + closeButtonSize, closeButtonTop + closeButtonSize); // ���ƹرհ�ť
    setcolor(BLACK);
    outtextxy(closeButtonLeft + 5, closeButtonTop + 3, "X");
}
//new�����������¼�
void clickAboutWindow() {
    // �ȱ��浱ǰ��Ļ
    int width = getmaxx();
    int height = getmaxy();
    IMAGE screenBackup; // ���Ա�����Ļ����
    getimage(&screenBackup, 0, 0, width, height); // ��ȡ������Ļ��ͼ��

    //��������
    popupAboutWindow();

    FlushMouseMsgBuffer();
    bool aboutWindowOpen = true;
    while (aboutWindowOpen) {
        if (MouseHit()) {
            MOUSEMSG m = GetMouseMsg();
            if (m.uMsg == WM_LBUTTONDOWN) {
                // �������Ǹ����Ŷ�����ʵ�ֵ���x�ر�Ч��
                int closeButtonLeft = 560;
                int closeButtonTop = 200;
                int closeButtonRight = closeButtonLeft + 40;
                int closeButtonBottom = closeButtonTop + 40;

                if (m.x >= closeButtonLeft && m.x <= closeButtonRight &&
                    m.y >= closeButtonTop && m.y <= closeButtonBottom) {
                    aboutWindowOpen = false;
                }
            }
        }
    }
    // �ָ�֮ǰ�������Ļ
    putimage(0, 0, &screenBackup);

    //freeimage(&screenBackup); �ͷ�image����������ʾ����û���������
}

// ����Ƿ����˰�ť
bool isButtonClicked(const Button& button, int mouseX, int mouseY) {
    return mouseX > button.x && mouseX < button.x + button.width &&
           mouseY > button.y && mouseY < button.y + button.height;
}

//������Ϸ����
void saveGame(const AI& ai, bool isEndgame, int hard, int playerScore, int aiScore, bool AIfirst) {
    char fileName[100] = {0};
    InputBox(fileName, 100, "Enter the name of the save file: ");
    strcat(fileName, ".txt");

    std::ofstream outFile(fileName);
    if (!outFile) {
        outtextxy(30, 790, "Error opening file!");
        return;
    }

    outFile << (isEndgame ? "1" : "0") << std::endl; // д���Ƿ�Ϊ�оֵĲ���ֵ
    outFile << hard << std::endl; // д���Ѷȵȼ�
    outFile << playerScore << std::endl; // д����ҷ���
    outFile << aiScore << std::endl; // д��AI����
    outFile << (AIfirst ? "1" : "0") << std::endl; // д���Ƿ�Ϊ�оֵĲ���ֵ

    // д��chessBoard����
    if(!isEndgame){
        for (int i = 0; i < GRID_NUM; i++) {
            for (int j = 0; j < GRID_NUM; j++) {
                outFile << ai.chessBoard[i][j] << " ";
            }
            outFile << std::endl;
        }
    }


    outFile.close();
    outtextxy(30, 790, "Game saved successfully.");
}


bool loadGame(AI& ai, bool& isEndgame, int& playerScore, int& aiScore, int& hard, bool& AIfirst) {
    char fileName[100] = {0};
    InputBox(fileName, 100, "Enter the name of the load file: ");
    strcat(fileName, ".txt");

    std::ifstream inFile(fileName);
    if (!inFile) {
        outtextxy(10, 10, "Error opening file!");
        return false;
    }

    char isEndgameChar;
    inFile >> isEndgameChar;
    isEndgame = (isEndgameChar == '1');

    int loadhard;
    inFile >> loadhard; // ��ȡ�Ѷȵȼ�
    hard = loadhard;

    inFile >> playerScore; // ��ȡ��ҷ���
    inFile >> aiScore; // ��ȡAI����
    inFile >> AIfirst;//��ȡ������Ϣ

    if (!isEndgame) {
        // ������ǲо֣��������ȡ������Ϣ
        for (int i = 0; i < GRID_NUM; i++) {
            for (int j = 0; j < GRID_NUM; j++) {
                inFile >> ai.chessBoard[i][j];
            }
        }
    }

    inFile.close();
    return true;
}

void writeStatusBar(char status_bar[], int playerScore, int aiScore, int hard, bool AIfirst){
    char player[50];

    switch (hard){
    case 0:
        sprintf(status_bar, "Player: %d, AI: %d  Difficulty: idiot  ", playerScore, aiScore);
        break;

    case 1:
        sprintf(status_bar, "Player: %d, AI: %d  Difficulty: very easy  ", playerScore, aiScore);
        break;

    case 2:
        sprintf(status_bar, "Player: %d, AI: %d  Difficulty: easy  ", playerScore, aiScore);
        break;

    case 3:
        sprintf(status_bar, "Player: %d, AI: %d  Difficulty: medium  ", playerScore, aiScore);
        break;

    case 4:
        sprintf(status_bar, "Player: %d, AI: %d  Difficulty: hard  ", playerScore, aiScore);
        break;
    }

    if(AIfirst){
        sprintf(player, "First Player: AI");
    }else{
        sprintf(player, "First Player: YOU");
    }

    strcat(status_bar, player);
}

// ��������
void drawChessboard() {
    setlinecolor(BLACK);

    for (int i = 0; i < GRID_NUM; ++i) {
        int pos = i * GRID_SIZE + HALF_GRID_SIZE;
        line(pos, HALF_GRID_SIZE, pos, WINDOW_SIZE - HALF_GRID_SIZE);
        line(HALF_GRID_SIZE, pos, WINDOW_SIZE - HALF_GRID_SIZE, pos);
    }

    setfillcolor(BLACK); // ����״̬���߿�
    fillrectangle(10, 740, 740, 890); // ���Ʊ߿�
    setfillcolor(GREEN);
    fillrectangle(15, 745, 735, 885);
}

// ���ƴ���ɫ�߿������
void drawPiece(int x, int y, int color) {
    int centerX = y * GRID_SIZE + HALF_GRID_SIZE;
    int centerY = x * GRID_SIZE + HALF_GRID_SIZE;

    // �������ӵĺ�ɫ�߿�
    setfillcolor(BLACK);
    solidcircle(centerX, centerY, BORDER_RADIUS);

    // ����ʵ�ʵ����ӣ���ɫ���ɫ��
    setfillcolor(color == BLACK_PIECE ? BLACK : WHITE);
    solidcircle(centerX, centerY, PIECE_RADIUS);
}

void drawLatestPiece(int x, int y, int color){
    int centerX = y * GRID_SIZE + HALF_GRID_SIZE;
    int centerY = x * GRID_SIZE + HALF_GRID_SIZE;

    // �������ӵĻ�ɫ�߿�
    setfillcolor(YELLOW);
    solidcircle(centerX, centerY, BORDER_RADIUS);

    // ����ʵ�ʵ����ӣ���ɫ���ɫ��
    setfillcolor(color == BLACK_PIECE ? BLACK : WHITE);
    solidcircle(centerX, centerY, PIECE_RADIUS);
}

// ���»������̺����ӣ������µ÷ְ�
void redrawChessboard(AI &ai, char status_bar[]) {
    cleardevice();
    drawChessboard();
    for (int i = 0; i < GRID_NUM; i++) {
        for (int j = 0; j < GRID_NUM; j++) {
            if (ai.chessBoard[i][j] != NONE) {
                drawPiece(i, j, ai.chessBoard[i][j]);
            }
        }
    }
    settextcolor(BLACK);
    outtextxy(30, 750, status_bar); // ����Ļ��һ���̶�λ����ʾ�÷ְ�
}


int main() {
    initgraph(WINDOW_SIZE, WINDOW_SIZE + 150);
    setbkcolor(GREEN);

    char status_bar[100];

    int playerScore=0, aiScore=0, hard=1;
    bool continueGame = true, AIfirst = false, Single = true;
    Button yesButton = {WINDOW_SIZE / 2 - 150, WINDOW_SIZE / 2, 100, 40, "Yes"};
    Button noButton = {WINDOW_SIZE / 2 + 50, WINDOW_SIZE / 2, 100, 40, "No"};
    Button hard1 = {WINDOW_SIZE / 2 - 275, WINDOW_SIZE / 2, 100, 40, "very easy"};
    Button hard2 = {WINDOW_SIZE / 2 - 125, WINDOW_SIZE / 2, 100, 40, "easy"};
    Button hard3 = {WINDOW_SIZE / 2 + 25, WINDOW_SIZE / 2, 100, 40, "medium"};
    Button hard4 = {WINDOW_SIZE / 2 + 175, WINDOW_SIZE / 2, 100, 40, "hard"};
    Button hard0 = {WINDOW_SIZE / 2 - 50, WINDOW_SIZE / 2 + 100, 100, 40, "idiot"};
    Button AI_first = {WINDOW_SIZE / 2 - 150, WINDOW_SIZE / 2, 100, 40, "AI"};
    Button Player_first = {WINDOW_SIZE / 2 + 50, WINDOW_SIZE / 2, 100, 40, "YOU"};
    Button Save = {600, 770, 115, 40, "SAVE GAME"};
    Button Load = {600, 830, 115, 40, "LOAD GAME"};
    Button multiplePlayer = {WINDOW_SIZE / 2 - 165, WINDOW_SIZE / 2, 130, 40, "Multiple Player"};
    Button singlePlayer = {WINDOW_SIZE / 2 + 65, WINDOW_SIZE / 2, 130, 40, "Single Player"};
    Button about= {WINDOW_SIZE / 2+300 , WINDOW_SIZE / 2-350, 30, 30, "?"};


    cleardevice(); // Ӧ�ñ���ɫ�������Ļ

    FlushMouseMsgBuffer();
    settextcolor(BLACK);
    outtextxy(WINDOW_SIZE / 2 - 70, 270, "Choose gameplay mode");
    drawButton(multiplePlayer);
    drawButton(singlePlayer);
    drawButton(about);

    bool modeClicked = false;
    while (!modeClicked) {
        if (MouseHit()) {
            MOUSEMSG m = GetMouseMsg();
            switch (m.uMsg) {
                case WM_LBUTTONDOWN:
                    if (isButtonClicked(multiplePlayer, m.x, m.y)) {
                        Single = false;
                        modeClicked = true;
                        break;
                    } else if (isButtonClicked(singlePlayer, m.x, m.y)) {
                        Single = true;
                        modeClicked = true;
                        break;
                    }
                        // ����� "����" ��ťʱ
                    else if (isButtonClicked(about, m.x, m.y)) {
                        clickAboutWindow();
                    }

            }
        }
    }


    cleardevice(); // Ӧ�ñ���ɫ�������Ļ
    drawChessboard();

    if(!Single){
        bool gameContinue = true;
        bool isPlayerOneTurn = true;
        bool isGameOver = false;

        while (gameContinue) {
            AI ai;
            cleardevice();
            drawChessboard();

            while (!isGameOver) {
                // �������¼�����
                FlushMouseMsgBuffer();
                if(isPlayerOneTurn){
                    sprintf(status_bar, "Player Two's turn");

                }else {
                    sprintf(status_bar, "Player One's turn");
                }

                if (MouseHit()) {
                    MOUSEMSG m = GetMouseMsg();
                    if (m.uMsg == WM_LBUTTONDOWN) {
                        int y = m.x / GRID_SIZE;
                        int x = m.y / GRID_SIZE;

                        if (ai.isValid(x, y) && ai.getPos(Point(x, y)) == NONE) {
                            int pieceColor = isPlayerOneTurn ? WHITE_PIECE : BLACK_PIECE;
                            ai.setPos(x, y, pieceColor);
                            redrawChessboard(ai, status_bar);
                            drawLatestPiece(x, y, pieceColor);

                            if (ai.isGameOver(x, y)) {
                                settextcolor(BLACK);
                                outtextxy(WINDOW_SIZE / 2 - 58, 270, isPlayerOneTurn ? "Player One wins!" : "Player Two wins!");
                                isGameOver = true;
                                break;
                            }

                            isPlayerOneTurn = !isPlayerOneTurn; // �л����
                        }
                    }
                }
            }

            // ��Ϸ������ѯ���Ƿ�����һ��
            settextcolor(BLACK);
            outtextxy(WINDOW_SIZE / 2 - 55, 290, "Play once more?");

            drawButton(yesButton);
            drawButton(noButton);

            // �������¼�����
            FlushMouseMsgBuffer();

            bool buttonClicked = false;
            while (!buttonClicked) {
                if (MouseHit()) {
                    MOUSEMSG m = GetMouseMsg();
                    switch (m.uMsg) {
                        case WM_LBUTTONDOWN:
                            if (isButtonClicked(yesButton, m.x, m.y)) {
                                gameContinue = true;
                                buttonClicked = true;
                                isGameOver = false; // ������Ϸ������־
                                isPlayerOneTurn = true; // ����Ϊ���һ��ʼ
                            } else if (isButtonClicked(noButton, m.x, m.y)) {
                                gameContinue = false;
                                buttonClicked = true;
                            }
                            break;
                    }
                }
            }
        }

        closegraph(); // �ر�ͼ�δ���
        return 0;
    }


    //������������
    FlushMouseMsgBuffer();
    settextcolor(BLACK);
    outtextxy(WINDOW_SIZE / 2 - 70, 270, "Choose the difficulty");
    drawButton(hard1);
    drawButton(hard2);
    drawButton(hard3);
    drawButton(hard4);
    drawButton(hard0);
    bool hardButtonClicked = false;
    while (!hardButtonClicked) {
        if (MouseHit()) {
            MOUSEMSG m = GetMouseMsg();
            switch (m.uMsg) {
                case WM_LBUTTONDOWN:
                    if (isButtonClicked(hard1, m.x, m.y)) {
                        hard=1;
                        hardButtonClicked = true;
                    } else if (isButtonClicked(hard2, m.x, m.y)) {
                        hard=2;
                        hardButtonClicked = true;
                    } else if (isButtonClicked(hard3, m.x, m.y)) {
                        hard=3;
                        hardButtonClicked = true;
                    } else if (isButtonClicked(hard4, m.x, m.y)) {
                        hard=4;
                        hardButtonClicked = true;
                    } else if (isButtonClicked(hard0, m.x, m.y)) {
                        hard=0;
                        hardButtonClicked = true;
                    }
                    break;
            }
        }
    }

    while (continueGame) {
        cleardevice(); // Ӧ�ñ���ɫ�������Ļ
        drawChessboard();

        FlushMouseMsgBuffer();

        outtextxy(WINDOW_SIZE / 2 - 85, 270, "Choose the Starting Player");
        drawButton(AI_first);
        drawButton(Player_first);
        bool firstHandClicked = false;
        while (!firstHandClicked) {
            if (MouseHit()) {
                MOUSEMSG m = GetMouseMsg();
                switch (m.uMsg) {
                    case WM_LBUTTONDOWN:
                        if (isButtonClicked(AI_first, m.x, m.y)) {
                            AIfirst = true;
                            firstHandClicked = true;
                        } else if (isButtonClicked(Player_first, m.x, m.y)) {
                            AIfirst = false;
                            firstHandClicked = true;
                        }
                        break;
                }
            }
        }

        AI ai;
        ai.setDep(hard);
        bool isPlayerTurn = true, isPlayerWin = false, isEndgame = false;
        writeStatusBar(status_bar, playerScore, aiScore, hard, AIfirst);

        if(AIfirst){
            Point first = ai.GetFirstStep();
            redrawChessboard(ai, status_bar);
            drawLatestPiece(first.x,first.y,BLACK_PIECE);
        } else {
            redrawChessboard(ai, status_bar);
        }


        while (true) {
            writeStatusBar(status_bar, playerScore, aiScore, hard, AIfirst);

            if (isPlayerTurn) {
                // �������¼�����
                FlushMouseMsgBuffer();

                outtextxy(30, 770, "Your turn");
                drawButton(Save);
                drawButton(Load);
                while (true) {
                    if (MouseHit()) {
                        MOUSEMSG m = GetMouseMsg();
                        if (m.uMsg == WM_LBUTTONDOWN) {
                            int y = m.x / GRID_SIZE;
                            int x = m.y / GRID_SIZE;

                            if (ai.isValid(x, y) && ai.getPos(Point(x, y)) == NONE) {
                                ai.setPos(x, y, WHITE_PIECE);
                                redrawChessboard(ai, status_bar);
                                drawLatestPiece(x, y, WHITE_PIECE);
                                if (ai.isGameOver(x, y)) {
                                    settextcolor(BLACK);
                                    outtextxy(WINDOW_SIZE / 2 - 85, 270, "Congratulations! You win!");
                                    playerScore++;
                                    isPlayerWin=true;
                                    break;
                                }
                                isPlayerTurn = false;
                                break;
                            } else if(isButtonClicked(Save, m.x, m.y)){
                                isEndgame = false;
                                saveGame(ai, isEndgame, hard, playerScore, aiScore, AIfirst);
                                break;
                            } else if(isButtonClicked(Load, m.x, m.y)){
                                loadGame(ai, isEndgame, playerScore, aiScore, hard, AIfirst);
                                ai.setDep(hard);
                                writeStatusBar(status_bar, playerScore, aiScore, hard, AIfirst);
                                redrawChessboard(ai, status_bar);
                                if(isEndgame)
                                    isPlayerWin=true;
                                break;
                            }
                        }
                    }
                }
            } else {
                settextcolor(BLACK);
                outtextxy(30, 770, "AI is thinking : ");

                Point p = ai.getNextStep(BLACK_PIECE);
                ai.setPos(p.x, p.y, BLACK_PIECE);
                redrawChessboard(ai, status_bar);
                drawLatestPiece(p.x, p.y, BLACK_PIECE);

                if (ai.isGameOver(p.x, p.y)) {
                    settextcolor(BLACK);
                    outtextxy(WINDOW_SIZE / 2 - 95, 270, "AI wins. Better luck next time!");
                    aiScore++;
                    break;
                }
                isPlayerTurn = true;
            }

            if(isPlayerWin)
                break;
        }

        // ���ƽ����Ծֺ�İ�ť
        settextcolor(BLACK);
        if(isEndgame)
            outtextxy(WINDOW_SIZE / 2 - 70, 270, "Chess board is empty");
        settextcolor(BLACK);
        outtextxy(WINDOW_SIZE / 2 - 55, 290, "Play once more?");
        drawButton(yesButton);
        drawButton(noButton);
        drawButton(Save);
        drawButton(Load);

        // �������¼�����
        FlushMouseMsgBuffer();

        bool buttonClicked = false;
        while (!buttonClicked) {
            if (MouseHit()) {
                MOUSEMSG m = GetMouseMsg();
                switch (m.uMsg) {
                    case WM_LBUTTONDOWN:
                        if (isButtonClicked(yesButton, m.x, m.y)) {
                            continueGame = true;
                            buttonClicked = true;
                        } else if (isButtonClicked(noButton, m.x, m.y)) {
                            continueGame = false;
                            buttonClicked = true;
                        } else if (isButtonClicked(Save, m.x, m.y)) {
                            isEndgame = true;
                            saveGame(ai, isEndgame, hard, playerScore, aiScore, AIfirst);
                        } else if (isButtonClicked(Load, m.x, m.y)) {
                            loadGame(ai, isEndgame, playerScore, aiScore, hard, AIfirst);
                            ai.setDep(hard);
                            writeStatusBar(status_bar, playerScore, aiScore, hard, AIfirst);
                        }
                        break;
                }
            }
        }

        // ������Ļ��׼����һ����Ϸ���˳�
        cleardevice();
    }

    closegraph(); // �ر�ͼ�δ���
    return 0;
}
